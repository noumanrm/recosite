<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?=  bloginfo( 'title' ); ?></title>
    <meta name="viewport" content="width=device-width">

    <?php $gtm_id = get_field( 'tag_manager_id', 'options' );
    if($gtm_id): ?>
    <!-- Google Tag Manager -->
    <script>
    (function(w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s),
            dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', '<?= $gtm_id ?>');
    </script>
    <!-- End Google Tag Manager -->
    <?php endif; ?>

    <?php $ga_code = get_field('google_analytics_code', 'options');
    if($ga_code): ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=<?= $ga_code ?>"></script>
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', '<?= $ga_code ?>');
    </script>
    <?php endif; ?>


    <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/favicons/favicon-16x16.png">
    <link rel="manifest" href="/favicons/site.webmanifest">
    <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#2d89ef">
    <meta name="theme-color" content="#ffffff">

    <?php wp_head(); ?>

    <script>
    // Set the options to make LazyLoad self-initialize
    window.lazyLoadOptions = {
        elements_selector: ".lazy",
        // ... more custom settings?
    };
    // Listen to the initialization event and get the instance of LazyLoad
    window.addEventListener('LazyLoad::Initialized', function(event) {
        window.lazyLoadInstance = event.detail.instance;
    }, false);

    function checkWebP(callback) {
        var webP = new Image();
        webP.onload = webP.onerror = function() {
            callback(webP.height == 2);
        };
        webP.src =
            'data:image/webp;base64,UklGRjoAAABXRUJQVlA4IC4AAACyAgCdASoCAAIALmk0mk0iIiIiIgBoSygABc6WWgAA/veff/0PP8bA//LwYAAA';
    };
    checkWebP(function(support) {
        if (support) {
            jQuery(document.body).addClass('webp');
        } else {
            jQuery(document.body).addClass('no-webp');
        }
    });
    </script>

    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@400;600&family=Roboto:wght@400;500&display=swap"
        rel="stylesheet">

</head>

<body <?php body_class(); ?>>

    <?php if($gtm_id): ?>
    <noscript>
        <iframe src="https://www.googletagmanager.com/ns.html?id=<?= get_field( 'tag_manager_id', 'options' ) ?>"
            height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>
    <?php endif; ?>

    <header class="header-outerwrap-section">
        <div class="header-top-section">
            <ul>
                <li>
                    <a href="#">Help for Yourself</a>
                </li>
                <li>
                    <a href="#">Help for a Loved One</a>
                </li>
                <li>
                    <a href="#">Referring Professionals</a>
                </li>
            </ul>
        </div>
        <div class="header-innerwrap-section">
            <div class="header-left">
                <div class="header-logo">
                    <a href="#">
                        <img src="<?php bloginfo('template_url'); ?>/images/header-logo.svg" alt="reco-logo">
                    </a>
                </div>
                <div class="header-navbar">
                    <ul>
                        <li>
                            <a href="#">about us</a>
                            <ul class="sub-menu">
                                <li>
                                    <a href="#">our staff</a>
                                </li>
                                <li>
                                    <a href="#">accreditations</a>
                                </li>
                                <li>
                                    <a href="#">Mission Statement</a>
                                </li>
                                <li>
                                    <a href="#">our alumni</a>
                                </li>
                                <li>
                                    <a href="#">alumni buddy</a>
                                </li>
                                <li>
                                    <div class="sub-menu-content">
                                        <h3>"Allowed me to build a life for myself."</h3>
                                        <p>Sober housing that RECO Institute provides is a cut above the rest all their
                                            houses are safe...</p>
                                        <a href="#">Alumni Testimonials</a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">alumni resources</a>
                            <ul class="sub-menu">
                                <li>
                                    <span>Whats the Word</span>
                                </li>
                                <li>
                                    <a href="#">Alumni Blog</a>
                                </li>
                                <li>
                                    <a href="#">Media</a>
                                </li>
                                <li>
                                    <a href="#">Alumni Testimonilas</a>
                                </li>
                                <li>
                                    <span>Activities</span>
                                </li>
                                <li>
                                    <a href="#">Alumni Events</a>
                                </li>
                                <li>
                                    <a href="#">Camping Trips</a>
                                </li>
                                <li>
                                    <a href="#">Find Meetings</a>
                                </li>
                                <li>
                                    <a href="#">
                                        <div class="sub-menu-content">
                                            <span>featured post</span>
                                            <img src="<?php bloginfo('template_url'); ?>/images/alumniresources-img.png"
                                                alt="">
                                            <p>4 ways regular yoga practice can give you a health leg up</p>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">our properties</a>
                            <ul class="sub-menu">
                                <li>
                                    <span>Female Residences</span>
                                </li>
                                <li>
                                    <a href="#">The Hart</a>
                                </li>
                                <li>
                                    <a href="#">The Siebold</a>
                                </li>
                                <li>
                                    <a href="#">The Van Epps</a>
                                </li>
                                <li>
                                    <span>Clinical & Administrative</span>
                                </li>
                                <li>
                                    <a href="#">Reco Towers</a>
                                </li>
                                <li>
                                    <a href="#">Reco Ranch</a>
                                </li>
                                <li>
                                    <span>Male Residences</span>
                                </li>
                                <li>
                                    <a href="#">The Parker</a>
                                </li>
                                <li>
                                    <a href="#">Reco Tapper</a>
                                </li>
                                <li>
                                    <a href="#">Reco Row</a>
                                </li>
                                <li>
                                    <a href="#">Check Availability</a>
                                </li>
                                <li>
                                    <a href="#">
                                        <img src="<?php bloginfo('template_url'); ?>/images/male-residence.svg" alt="">
                                    </a>
                                    <a href="#">
                                        <img src="<?php bloginfo('template_url'); ?>/images/female-residence.svg"
                                            alt="">
                                    </a>
                                    <a href="#">
                                        <img src="<?php bloginfo('template_url'); ?>/images/reco-towers.svg" alt="">
                                    </a>
                                    <a href="#">
                                        <img src="<?php bloginfo('template_url'); ?>/images/reco-ranch.svg" alt="">
                                    </a>
                                </li>
                                
                            </ul>
                        </li>
                        <li>
                            <a href="#">admissions</a>
                            <ul class="sub-menu">

                                <li>
                                    <a href="#">Sober Living Housing Guidelines</a>
                                </li>
                                <li>
                                    <a href="#">Availability</a>
                                </li>
                                <li>
                                    <a href="#">Addiction Treatment</a>
                                </li>
                                <li>
                                    <a href="#">FAQs</a>
                                </li>
                                <li>
                                    <a href="#">verify Insurance</a>
                                </li>

                                <li>
                                    <div class="sub-menu-content">
                                        <img src="<?php bloginfo('template_url'); ?>/images/admissions-img.png" alt="">
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">reco shop</a>
                            <ul class="sub-menu">
                                <li>
                                    <div class="sub-menu-content">
                                        <h3>Shop fearless looks</h3>
                                        <p>Wear your heart on yours sleeve with our clothing tailored towards what makes
                                            you uniquely you.</p>
                                        <a href="#">Reco Shop</a>
                                    </div>
                                </li>
                                <li>
                                    <div class="sub-menu-content">
                                        <img src="<?php bloginfo('template_url'); ?>/images/alumniresources-img.png"
                                            alt="">
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="#">contact</a>
                            <ul class="sub-menu">
                                <li>
                                    <span>RECO Institute</span>
                                </li>
                                <li>
                                    <p>140 NE 4th Avenue Delray Beach, FL33483</p>
                                </li>
                                <li>
                                    <p><b>Local</b> 561.237.7368</p>
                                </li>
                                <li>
                                    <a href="#"><b>Toll-Free</b> 855.799.1035</a>
                                </li>
                                <li>
                                    <b>renew.restore.recover.</b>
                                </li>

                                <li>
                                    <div class="social-icons">
                                        <a href="#"><img src="<?php bloginfo('template_url') ;?>/images/instagram.svg"
                                                alt=""></a>
                                        <a href="#"><img src="<?php bloginfo('template_url') ;?>/images/fb.svg"
                                                alt=""></a>
                                        <a href="#"><img src="<?php bloginfo('template_url') ;?>/images/twitter.svg"
                                                alt=""></a>
                                        <a href="#"><img src="<?php bloginfo('template_url') ;?>/images/youtube.svg"
                                                alt=""></a>
                                    </div>
                                </li>
                                <li>
                                    <div class="sub-menu-content">
                                        <img src="<?php bloginfo('template_url') ;?>/images/map.svg" alt="">
                                    </div>
                                </li>
                            </ul>
                        </li>
                    </ul>

                </div>
            </div>
            <div class="contact-no">
                <a href="#">844.960.3156</a>
                <ul>
                    <li><a href="#">copy</a></li>
                    <li><a href="tel:844.960.3156">call now</a></li>
                </ul>
            </div>
        </div>
        <div class="header-right mobile" style="display: none;">
        <div class="hamburger">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    <div class="nav-menu">
        <div class="container">
            <?php
            wp_nav_menu( array(
                'menu' => 'mobile-menu'
            ) );
            ?>
        </div>
    </div>
    </header>
    <main class="site-content">