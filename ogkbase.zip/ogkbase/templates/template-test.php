<?php
/* Template Name: Test Page */
get_header();


get_template_part("sections/section", "test");


get_footer();
