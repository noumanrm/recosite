<section class="wlecome-sections">
    <?php the_field('welcome_content'); ?>
</section>