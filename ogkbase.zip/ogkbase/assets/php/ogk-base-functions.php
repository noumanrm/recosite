<?php


// helper to check if the current page is the login screen
function is_login_page() {
    return !strncmp($_SERVER['REQUEST_URI'], '/wp-login.php', strlen('/wp-login.php'));
}


// deregister styles  & setup cache
add_action('wp_print_styles', 'ogk_deregister_styles', 100);
function ogk_deregister_styles() {

    if ( !is_admin() ) :

        global $theme_setup;
        global $wp_styles;

        if ( !is_user_logged_in() && !is_login_page() ) {

            if ( $theme_setup['disable_dash_icon_styles'] ) :
                wp_deregister_style('dashicons');
            endif;

            if ( $theme_setup['disable_admin_bar_styles'] ) :
                wp_deregister_style('admin-bar');
            endif;

        }

        if ( $theme_setup['disable_block_library'] ) :
            wp_deregister_style('wp-block-library');
        endif;

    endif;

}

/**
 *  Reusable Sections
 *
 *  The function that grabs all section parts from the sections folder
 */
function ogk_get_reusable_sections() {
    $files = glob(get_template_directory() . '/sections/*');

    foreach ($files as $file) {
        $filename = basename($file, '.php');
        $file_str_name = str_replace('section-', '', $filename);
        $file_layout_name = str_replace('-', '_', $file_str_name);
        $file_layout_name .= '_section';

        if (get_row_layout() == $file_layout_name ) {
            get_template_part('sections/section', $file_str_name);
        }
    }
}

/**
 *  OGK Button
 *
 *  The function that renders a button
 * @param string $class
 * @param bool $download
 * @param string $link_selector
 * @param string $text_selector
 *
 * @return string
 */
function ogk_button( $class, $download = false, $link_selector = 'button_link', $text_selector = 'button_text' ) {
    ob_start(); ?>
    <div class="btn-wrap">
        <a href="<?= get_sub_field($link_selector) ?>" class="<?= $class ?>"<?php if($download == true): ?> download<?php endif; ?>><?= get_sub_field($text_selector) ?></a>
    </div>
    <?php echo ob_get_clean();
}


/**
 *   Create ACF options pages
 */
// ACF option pages
if ( function_exists( 'acf_add_options_page' ) ) {

    acf_add_options_page( array(
        'page_title' => 'Site Settings',
        'menu_title' => 'Site Settings',
        'menu_slug'  => 'site-settings',
        'capability' => 'edit_posts',
        'redirect'   => false
    ) );

}




/** =========================================================================================== **/
/**
 *  THEMED LOGIN PAGE
 */
function custom_login() { ?>
    <style type="text/css">
        body {
            background-color: #11090B !important;
            color: #222 !important;
        }

        .login .message, .login .success, .login #login_error {
            background-color: #eee !important;
            color: #11090B;
            border-left-color: #999 !important;
        }

        #login form {
            background: #eee;
        }

        form .submit input {
            background: #11090B !important;
            color: #fff !important;
            box-shadow: none !important;
            text-shadow: none !important;
            border-radius: 0 !important;
            border: none !important;
            text-transform: uppercase;
            font-weight: 700;

        }

        form .submit input:hover {
            background: #fff !important;
            color: #11090B !important;
            border: 2px solid #ddd !important;
        }

        #login h1 a, .login h1 a {
            background-image: url(<?= get_template_directory_uri() ?>/images/OGK_Logo_White.svg);
            height: 65px;
            width: 320px;
            background-size: 320px 65px;
            background-repeat: no-repeat;
            padding-bottom: 30px;
        }

        #login path {
            fill: #000;
        }
    </style>
<?php }

add_action( 'login_enqueue_scripts', 'custom_login' );

/** =========================================================================================== **/
/**
 * @return string|void
 * Login Logo to redirect to homepage
 */
function my_login_logo_url() {
    return home_url();
}

add_filter( 'login_headerurl', 'my_login_logo_url' );

/** =========================================================================================== **/

add_theme_support( 'menus' ); // add menus
add_theme_support( 'post-thumbnails' ); // add featured iamges
add_post_type_support( 'page', 'excerpt' ); // add excerpts

/** =========================================================================================== **/

/**
 * REGISTER MAIN MENU
 */
function register_my_menu() {
    register_nav_menus(
        array(
            'main-menu'   => __( 'Main Menu' ),
            'footer-menu' => __( 'Footer Menu' )
        )
    );
}

add_action( 'init', 'register_my_menu' );

/**
 * @param $ulclass
 *
 * @return string|string[]|null
 */
function add_menuclass( $ulclass ) {
    return preg_replace( '/<a/', '<a class="menu-item"', $ulclass, - 1 );
}

add_filter( 'wp_nav_menu', 'add_menuclass' );

/** =========================================================================================== **/

/**
 * Allow shortcodes in menu items
 *
 * @param $items
 * @param $args
 *
 * @return string
 */
function wp_nav_menu_items( $items, $args ) {
    $items = do_shortcode( $items );

    return $items;
}

add_filter( 'wp_nav_menu_items', 'wp_nav_menu_items', 10, 2 );

/** =========================================================================================== **/

/**
 * add SVG to allowed file uploads
 *
 * @param $file_types
 *
 * @return array
 */
function add_file_types_to_uploads( $file_types ) {

    $new_filetypes        = array();
    $new_filetypes['svg'] = 'image/svg+xml';
    $file_types           = array_merge( $file_types, $new_filetypes );

    return $file_types;
}

add_action( 'upload_mimes', 'add_file_types_to_uploads' );

/** =========================================================================================== **/

/**
 * OGKlip function
 * Missy's function for clipping a string to a desired length.
 */
function ogklip( $string, $width = 100 ) {
    $wrapped = wordwrap( $string, $width );
    $lines   = explode( "\n", $wrapped );
    $new_str = $lines[0] . '...';

    return $new_str;
}
/** =========================================================================================== **/

/** 
 * CPT Our Team
 * **/
function my_custom_post_team() {
    $labels = array(
      'name'               => _x( 'Our Team', 'post type general name' ),
      'singular_name'      => _x( 'Our Team', 'post type singular name' ),
      'add_new'            => _x( 'Add New', 'team' ),
      'add_new_item'       => __( 'Add New Team Member' ),
      'edit_item'          => __( 'Edit Team Member' ),
      'new_item'           => __( 'New Our Team' ),
      'all_items'          => __( 'All Our Team' ),
      'view_item'          => __( 'View Our Team' ),
      'search_items'       => __( 'Search Our Team' ),
      'not_found'          => __( 'No Our Team found' ),
      'not_found_in_trash' => __( 'No Our Team found in the Trash' ), 

      'menu_name'          =>  __( 'Our Team' )
    );
    $args = array(
      'labels'        => $labels,
      'public'        => true,
      'menu_position' => 5,
      'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
      'has_archive'   => true,
    );
    register_post_type( 'Our Team', $args ); 
  }
  add_action( 'init', 'my_custom_post_team' );

  function my_taxonomies_team() {
    $labels = array(
      'name'              => _x( 'Our Team Categories', 'taxonomy general name' ),
      'singular_name'     => _x( 'Our Team Category', 'taxonomy singular name' ),
      'search_items'      => __( 'Search Our Team Categories' ),
      'all_items'         => __( 'All Our Team Categories' ),
      'parent_item'       => __( 'Parent Our Team Category' ),
      'parent_item_colon' => __( 'Parent Our Team Category:' ),
      'edit_item'         => __( 'Edit Our Team Category' ), 
      'update_item'       => __( 'Update Our Team Category' ),
      'add_new_item'      => __( 'Add New Our Team Category' ),
      'new_item_name'     => __( 'New Our Team Category' ),
      'menu_name'         => __( 'Our Team Categories' ),
    );
    $args = array(
      'labels' => $labels,
      'hierarchical' => true,
    );
    register_taxonomy( 'team_category', 'ourteam', $args );
  }
  add_action( 'init', 'my_taxonomies_team', 0 );

  /** CPT Addiction Treatment **/

  function my_custom_addiction_treatment() {
    $labels = array(
      'name'               => _x( 'Addiction Treatment', 'post type general name' ),
      'singular_name'      => _x( 'Addiction Treatment', 'post type singular name' ),
      'add_new'            => _x( 'Addiction Treatment', 'team' ),
      'add_new_item'       => __( 'Add New Addiction Treatment' ),
      'edit_item'          => __( 'Edit Addiction Treatment' ),
      'new_item'           => __( 'New Addiction Treatment' ),
      'all_items'          => __( 'All Addiction Treatment' ),
      'view_item'          => __( 'View Addiction Treatment' ),
      'search_items'       => __( 'Search Addiction Treatment' ),
      'not_found'          => __( 'No Addiction Treatment found' ),
      'not_found_in_trash' => __( 'No Addiction Treatment found in the Trash' ), 

      'menu_name'          =>  __( 'Addiction Treatment' )
    );
    $args = array(
      'labels'        => $labels,
      'public'        => true,
      'menu_position' => 5,
      'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
      'has_archive'   => true,
    );
    register_post_type( 'Addiction Treatment', $args ); 
  }
  add_action( 'init', 'my_custom_addiction_treatment' );


  /**CPT Therapeutic Excursions **/
  function my_custom_post_therapeutic() {
    $labels = array(
      'name'               => _x( 'Therapeutic Excursions', 'post type general name' ),
      'singular_name'      => _x( 'Therapeutic Excursions', 'post type singular name' ),
      'add_new'            => _x( 'Add New', 'Therapeutic Excursions' ),
      'add_new_item'       => __( 'Add New Therapeutic Excursions' ),
      'edit_item'          => __( 'Edit Therapeutic Excursions' ),
      'new_item'           => __( 'New Therapeutic Excursions' ),
      'all_items'          => __( 'All Therapeutic Excursions' ),
      'view_item'          => __( 'View Therapeutic Excursions' ),
      'search_items'       => __( 'Search Therapeutic Excursions' ),
      'not_found'          => __( 'No Therapeutic Excursions found' ),
      'not_found_in_trash' => __( 'No Therapeutic Excursions found in the Trash' ), 

      'menu_name'          =>  __( 'Therapeutic Excursions' )
    );
    $args = array(
      'labels'        => $labels,
      'public'        => true,
      'menu_position' => 5,
      'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
      'has_archive'   => true,
    );
    register_post_type( 'Therapeutic', $args ); 
  }
  add_action( 'init', 'my_custom_post_therapeutic' );

  /** CPT Group Therapy  **/
  function my_custom_post_therapy() {
    $labels = array(
      'name'               => _x( 'Group Therapy', 'post type general name' ),
      'singular_name'      => _x( 'Group Therapy', 'post type singular name' ),
      'add_new'            => _x( 'Add New', 'Group Therapy' ),
      'add_new_item'       => __( 'Add New Group Therapy' ),
      'edit_item'          => __( 'Edit Group Therapy' ),
      'new_item'           => __( 'New Group Therapy' ),
      'all_items'          => __( 'All Group Therapy' ),
      'view_item'          => __( 'View Group Therapy' ),
      'search_items'       => __( 'Search Group Therapy' ),
      'not_found'          => __( 'No Group Therapy found' ),
      'not_found_in_trash' => __( 'No Group Therapy found in the Trash' ), 

      'menu_name'          =>  __( 'Group Therapy' )
    );
    $args = array(
      'labels'        => $labels,
      'public'        => true,
      'menu_position' => 5,
      'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
      'has_archive'   => true,
    );
    register_post_type( 'Group Therapy', $args ); 
  }
  add_action( 'init', 'my_custom_post_therapy' );

  /* CPT ALUMNI EVENTS */

  function my_custom_post_events() {
    $labels = array(
      'name'               => _x( 'Alumni Events', 'post type general name' ),
      'singular_name'      => _x( 'Alumni Event', 'post type singular name' ),
      'add_new'            => _x( 'Add New', 'Alumni Events' ),
      'add_new_item'       => __( 'Add New Alumni Events' ),
      'edit_item'          => __( 'Edit Alumni Events' ),
      'new_item'           => __( 'New Alumni Events' ),
      'all_items'          => __( 'All Alumni Events' ),
      'view_item'          => __( 'View Alumni Events' ),
      'search_items'       => __( 'Search Alumni Events' ),
      'not_found'          => __( 'No Alumni Events found' ),
      'not_found_in_trash' => __( 'No Alumni Events found in the Trash' ), 

      'menu_name'          =>  __( 'Alumni Events' )
    );
    $args = array(
      'labels'        => $labels,
      'public'        => true,
      'menu_position' => 5,
      'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
      'has_archive'   => true,
    );
    register_post_type( 'Alumni events', $args ); 
  }
  add_action( 'init', 'my_custom_post_events' );


    /* CPT OUR PRPERTIES */

    function my_custom_post_properties() {
        $labels = array(
          'name'               => _x( 'Our Properties', 'post type general name' ),
          'singular_name'      => _x( 'Our Properties', 'post type singular name' ),
          'add_new'            => _x( 'Add New', 'Our Properties' ),
          'add_new_item'       => __( 'Add New Our Properties' ),
          'edit_item'          => __( 'Edit Our Properties' ),
          'new_item'           => __( 'New Our Properties' ),
          'all_items'          => __( 'All Our Properties' ),
          'view_item'          => __( 'View Our Properties' ),
          'search_items'       => __( 'Search Our Properties' ),
          'not_found'          => __( 'No Our Properties found' ),
          'not_found_in_trash' => __( 'No Our Properties found in the Trash' ), 
    
          'menu_name'          =>  __( 'Our Properties' )
        );
        $args = array(
          'labels'        => $labels,
          'public'        => true,
          'menu_position' => 5,
          'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
          'has_archive'   => true,
          'hierarchical'        => true,
          'show_ui'             => true,
          'show_in_menu'        => true,
          'show_in_nav_menus'   => true,
          'show_in_admin_bar'   => true,
          'exclude_from_search' => true,
          'publicly_queryable'  => true,
          'capability_type'     => 'page',
          'show_in_rest'        => true,
        );
        register_post_type( 'Our Properties', $args ); 
      }
      add_action( 'init', 'my_custom_post_properties' );
      function my_taxonomies_properties() {
        $labels = array(
          'name'              => _x( 'Our Properties Categories', 'taxonomy general name' ),
          'singular_name'     => _x( 'Our Properties Category', 'taxonomy singular name' ),
          'search_items'      => __( 'Search Our Properties Categories' ),
          'all_items'         => __( 'All Our Properties Categories' ),
          'parent_item'       => __( 'Parent Our Properties Category' ),
          'parent_item_colon' => __( 'Parent Our Properties Category:' ),
          'edit_item'         => __( 'Edit Our Properties Category' ), 
          'update_item'       => __( 'Update Our Properties Category' ),
          'add_new_item'      => __( 'Add New Our Property Category' ),
          'new_item_name'     => __( 'New Our Properties Category' ),
          'menu_name'         => __( 'Our Properties Categories' ),
        );
        $args = array(
          'labels' => $labels,
          'hierarchical' => true,
          'show_ui' => true,
          'show_in_rest' => true,
          'show_admin_column' => true,
          'query_var' => true
        );
        register_taxonomy( 'properties_category', 'ourproperties', $args );
      }
      add_action( 'init', 'my_taxonomies_properties', 0 );



      function sm_custom_meta() {
        add_meta_box( 'sm_meta', __( 'Featured Posts', 'sm-textdomain' ), 'sm_meta_callback', 'post' );
    }
    function sm_meta_callback( $post ) {
        $featured = get_post_meta( $post->ID );
        ?>
     
      <p>
        <div class="sm-row-content">
            <label for="meta-checkbox">
                <input type="checkbox" name="meta-checkbox" id="meta-checkbox" value="yes" <?php if ( isset ( $featured['meta-checkbox'] ) ) checked( $featured['meta-checkbox'][0], 'yes' ); ?> />
                <?php _e( 'Featured this post', 'sm-textdomain' )?>
            </label>
            
        </div>
    </p>
     
        <?php
    }
    add_action( 'add_meta_boxes', 'sm_custom_meta' );

    /**
 * Saves the custom meta input
 */
function sm_meta_save( $post_id ) {
 
  // Checks save status
  $is_autosave = wp_is_post_autosave( $post_id );
  $is_revision = wp_is_post_revision( $post_id );
  $is_valid_nonce = ( isset( $_POST[ 'sm_nonce' ] ) && wp_verify_nonce( $_POST[ 'sm_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

  // Exits script depending on save status
  if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
      return;
  }

// Checks for input and saves
if( isset( $_POST[ 'meta-checkbox' ] ) ) {
  update_post_meta( $post_id, 'meta-checkbox', 'yes' );
} else {
  update_post_meta( $post_id, 'meta-checkbox', '' );
}

}
add_action( 'save_post', 'sm_meta_save' );

