<?php get_header(); ?>

<?php while(have_posts()): the_post(); ?>
<h2><?php the_title(); ?></h2>
<p>Stay connected with the RECO Alumni community through fun exciting events. Check back often to see what’s new. </p>
<?php $url = wp_get_attachment_url( get_post_thumbnail_id($loop->ID) ); ?>
                <img src="<?php echo $url; ?>" alt="">

                <span><?php the_field('event_date_&_time'); ?></span>
                <p><?php the_field('event_address'); ?></p>
                <?= apply_filters('the_content', $post->post_content); ?>
                <?php endwhile; ?>

<?php get_footer(); ?>