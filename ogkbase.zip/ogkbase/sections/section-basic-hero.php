<section class="basic-hero-section">
    <div class="banner-video">
        <video autoplay playsinline muted loop class="hero-video-bkg">
            <source src="<?= get_sub_field('basic_hero_bg') ?>">
        </video>
    </div>
    <h1 class="tc-wht"><?= get_sub_field('basic_hero_title') ?></h1>
    <?php if(is_front_page()): ?>
        <div class="banner-scroll"><a href="#">scroll</a></div>
    <?php endif; ?>
</section>