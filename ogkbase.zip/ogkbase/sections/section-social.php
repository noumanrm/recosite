<?php

	echo __FILE__;

	/* TODO: add social feeds display to grab post text  */