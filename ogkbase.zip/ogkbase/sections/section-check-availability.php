<section class="check-availability-section">
    <div class="check-availability-outerwrap">
        <h2><?php the_sub_field('check_availability_heading'); ?></h2>
        <div class="check-availability-form">
            <?php the_sub_field('check_availability_form'); ?>
        </div>
    </div>
</section>