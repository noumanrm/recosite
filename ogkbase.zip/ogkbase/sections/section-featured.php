<?php

echo __FILE__;

/* TODO: add get post data display to grab post text  */