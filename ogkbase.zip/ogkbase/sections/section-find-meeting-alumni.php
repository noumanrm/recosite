<section class="find-meeting-alumni-section">
    <div class="find-meeting-alumni-outerwrap">
        <div class="find-meeting-alumni-innerwrap">
            <h1>Find an A.A. meeting Near You</h1>
            <p>Search for nearby alcoholics anonymous meetings.</p>
        </div>
    </div>
</section>