<section class="verify-insurance-form-section">
    <div class="verify-insurance-form-outerwrap">
        <h2><?php the_sub_field('verify_insurance_form_heading'); ?></h2>
        <?php the_sub_field('verify_insurance_form_content'); ?>

        <?php the_sub_field('verify_insurance_form'); ?>
        <div class="verify-insurance-form-content">
            <?php the_sub_field('verify_insurance_form_content2'); ?>
        </div>
    </div>
</section>