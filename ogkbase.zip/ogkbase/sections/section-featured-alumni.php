<section class="featured-alumni-section">
    <!-- <div class="container"> -->
         <h2><?php the_sub_field('section_heading'); ?></h2>
         <div class="alumni-bestblog-innerwrap">
            <div class="alumni-bestblog-img">
                <img src="<?php bloginfo('template_url'); ?>/images/latest-blog.png" alt="">
            </div>
            <div class="alumni-bestblog-content">
                <a href="#">featured alumni</a>
                <span>May 5, 2022</span>
                <h2>Our featured May Alumn, Meet Katherine.</h2>
                <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore…</p>
            </div>
         </div>
    <!-- </div> -->
</section>