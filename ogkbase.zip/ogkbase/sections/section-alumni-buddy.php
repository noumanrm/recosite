<section class="alumni-buddy-section">
    <div class="alumni-buddy-form-outerwrap">
        <?php the_sub_field('alumni_buddy_form'); ?>
        <div class="alumni-buddy-btn-img">
            <img src="<?php bloginfo('template_url'); ?>/images/our-alumni-heading-img.png" alt="">
        </div>
    </div>
</section>