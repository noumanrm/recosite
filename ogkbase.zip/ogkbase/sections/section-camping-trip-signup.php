<section class="camping-trip-signup-section">
    <div class="camping-trip-signup-content-outerwrap">
        <h2><?php the_sub_field('camping_trip_signup_heading'); ?></h2>
        <div class="camping-trip-signup-form">
            <?php the_sub_field('camping_trip_signup_form'); ?>
        </div>
    </div>
</section>