</main>
<footer>
    <div class="footer-top">
        <div class="footer-top-left">
            <div class="footer-logo">
                <a href="<?php echo get_home_url(); ?>">
                <img src="<?php the_field('logo','options'); ?>" alt=""></a>
            </div>
            <div class="footer-top-left-contact">
                <a href="tel:<?php the_field('phone','options'); ?>"><span>local</span><?php the_field('phone','options'); ?></a>
                <a href="tel:<?php the_field('toll_free','options'); ?>"><span>Toll Free</span><?php the_field('toll_free','options'); ?></a>
                <a href="tel:<?php the_field('fax','options'); ?>"><span>Fax</span><?php the_field('fax','options'); ?></a>
                <a href="mailto:<?php the_field('email','options'); ?>"><b><?php the_field('email','options'); ?></b></a>
            </div>
            <div class="footer-top-left-address">
                <p><?php the_field('address','options'); ?> <?php the_field('city','options'); ?>, <?php the_field('state','options'); ?></p>
            </div>
           
            <?php get_template_part("includes/social-icons"); ?>
        </div>
        <div class="footer-top-right footer-navbar">
            <ul>
                <li>
                    <span>Alumni Resources</span>
                </li>
                <?php if(have_rows('alumni_resources','options')): ?>
                    <?php while(have_rows('alumni_resources','options')): the_row(); ?>
                <li>
                    <a href="<?php the_sub_field('page_url','options'); ?>"><?php the_sub_field('page_name','options'); ?></a>
                </li>
                <?php endwhile; ?>
                     <?php endif; ?>
                
            </ul>
            <ul>
                <li>
                    <span>Quick Links</span>
                </li>
                <?php if(have_rows('quick_links','options')): ?>
                    <?php while(have_rows('quick_links','options')): the_row(); ?>
                <li>
                    <a href="<?php the_sub_field('page_url','options'); ?>"><?php the_sub_field('page_name','options'); ?></a>
                </li>
                <?php endwhile; ?>
                     <?php endif; ?>
                
            </ul>
            <ul>
                <li>
                    <span>About Us</span>
                </li>
                <?php if(have_rows('about_us','options')): ?>
                    <?php while(have_rows('about_us','options')): the_row(); ?>
                <li>
                    <a href="<?php the_sub_field('page_url','options'); ?>"><?php the_sub_field('page_name','options'); ?></a>
                </li>
                <?php endwhile; ?>
                     <?php endif; ?>
                
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
    <div class="footer-bottom-left">
        <ul>
            <li>
                <a href="#">
                    <img src="<?php bloginfo('template_url'); ?>/images/RECO_Accreditations.svg" alt="">
                </a>
            </li>
        </ul>
    </div>
    <div class="footer-bottom-right">
        <div class="footer-copyright">
            <div class="tree">
                <img src="<?php bloginfo('template_url'); ?>/images/tree.svg" alt="">
            </div>
            <p><?php the_field('copyright_text','options'); ?></p>
            <div class="tree">
                <img src="<?php bloginfo('template_url'); ?>/images/tree.svg" alt="">
            </div>
        </div>
    </div>
    </div>
</footer>

<?php wp_footer(); ?>

</body>

</html>