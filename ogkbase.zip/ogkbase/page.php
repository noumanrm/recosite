<?php get_header(); ?>

<?php get_template_part("includes/flexible"); ?>

<?php get_footer(); ?>
