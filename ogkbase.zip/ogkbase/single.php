<?php get_header(); ?>
<?php while(have_posts()): the_post(); ?>

<section class="blog-single-internal-page">
        <h1><?= get_the_title(); ?></h1>
        <?php $url = wp_get_attachment_url( get_post_thumbnail_id($loop->ID) ); ?>
                <img src="<?php echo $url; ?>" alt="">
        <?= apply_filters('the_content', $post->post_content); ?> 
        
</section>

<?php endwhile; ?>
<?php get_footer(); ?>
